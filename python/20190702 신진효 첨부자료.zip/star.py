#!/usr/bin/env python
# coding: utf-8

# In[2]:


a = 1


# In[3]:


_b = 2


# In[5]:


def x():
    return 1


# In[6]:


def _y():
    return 2


# In[7]:


__all__ = [a]


# In[ ]:




